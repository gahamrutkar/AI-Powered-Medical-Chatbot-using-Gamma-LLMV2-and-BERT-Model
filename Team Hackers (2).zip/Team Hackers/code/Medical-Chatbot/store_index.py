from langchain_community.vectorstores import Pinecone as PineconeStore  # Updated import
from pinecone import Pinecone, ServerlessSpec
import os
from dotenv import load_dotenv  # Ensure this package is installed

from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader  # Updated imports
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings  # Updated import

# Extract data from the PDF
def load_pdf(data):
    loader = DirectoryLoader(data, glob="*.pdf", loader_cls=PyPDFLoader)
    documents = loader.load()
    return documents

# Split or create text chunks 
def text_split(extracted_data):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
    text_chunks = text_splitter.split_documents(extracted_data)
    return text_chunks

# Download embedding model 
def download_hugging_face_embeddings():
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    return embeddings

# Load environment variables from a `.env` file
load_dotenv()

PINECONE_API_KEY = os.environ.get("PINECONE_API_KEY")
PINECONE_API_ENV = os.environ.get("PINECONE_API_ENV")

# Validate if environment variables are loaded
if not PINECONE_API_KEY or not PINECONE_API_ENV:
    print("Error: Please set PINECONE_API_KEY and PINECONE_API_ENV environment variables.")
    exit(1)

# Initialize Pinecone client
pc = Pinecone(api_key=PINECONE_API_KEY, environment=PINECONE_API_ENV)

# Define index name
index_name = "medical-bot"

# Load and process PDF data
extracted_data = load_pdf("data/")
text_chunks = text_split(extracted_data)
embeddings = download_hugging_face_embeddings()

# Check if the index already exists
if index_name not in pc.list_indexes().names():  # Ensure this method is correct
    # Create the index with desired configuration
    pc.create_index(
        name=index_name,
        dimension=384,  # Set the dimension based on your embedding model
        metric="cosine",  # Set the metric for similarity
        spec=ServerlessSpec(cloud="aws", region=PINECONE_API_ENV),  # Use API_ENV for region
    )
    print(f"Index '{index_name}' created successfully.")
else:
    print(f"Index '{index_name}' already exists.")

# Store vectors in Pinecone using the initialized client
docsearch = PineconeStore.from_texts(
    [t.page_content for t in text_chunks],
    embeddings,  # This should be the instance of HuggingFaceEmbeddings
    index_name=index_name,
    # pinecone_client=pc  # Uncomment if you need to pass the Pinecone client here
)

print(f"Documents added to Pinecone index '{index_name}'.")
