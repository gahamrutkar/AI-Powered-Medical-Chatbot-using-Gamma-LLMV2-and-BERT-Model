# Medical-Chatbot
#step to run the project 
#step 1 : create virtual environment ---> conda create -n mchatbot python=3.8 -y
#step2 : conda acitvate : --> conda activate mchatbot
#step3 : installing requirements.-->pip install -r requirements.txt

#step4: create ipynb and add basic libraries 
#step5 : create seperate folder called as data and model and add book pdf to data and model to model folder.

#step6 : go to pinecone and create api key and env by creatin index
#step 7: create function to load data from book 
#step 8: extract data from pdf 
#step9: create text chunks according to diagram
#step10: create embeddings 
#step11: to access the pinecone and store the vector db , check in pinecone if they are created or not.
#step12: creating prompt template 
#step13: testing sample input 
================================
#step 14 installing python libraries and flask 
#step15: go tp app.py file and create the front end part 