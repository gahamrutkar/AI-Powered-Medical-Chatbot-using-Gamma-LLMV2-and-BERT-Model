# Update for document loaders
from langchain_community.document_loaders import DirectoryLoader
#

from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader

# Update for embeddings
from langchain_community.embeddings import HuggingFaceEmbeddings

# Update for LLMs
from langchain_community.llms import CTransformers

from flask import Flask, render_template, jsonify, request
from langchain_community.embeddings import HuggingFaceEmbeddings
#from src.helper import download_hugging_face_embeddings
from langchain_community.vectorstores import Pinecone as PineconeStore  
#from langchain_huggingface import HuggingFaceEmbeddings  # Correct import for HuggingFaceEmbeddings
from langchain.prompts import PromptTemplate
#from langchain.llms import CTransformers

from langchain.chains import RetrievalQA
from dotenv import load_dotenv
from src.prompt import *
from store_index import load_pdf  # Ensure this function is implemented correctly
import os
from pinecone import Pinecone  # Correctly import Pinecone class
from langchain.text_splitter import RecursiveCharacterTextSplitter

app = Flask(__name__)

# Load environment variables
load_dotenv()

PINECONE_API_KEY = os.environ.get('PINECONE_API_KEY')
PINECONE_API_ENV = os.environ.get('PINECONE_API_ENV')

# Load extracted data
extracted_data = load_pdf("data/")

# Create a function to split text
def split_text(extracted_data):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
    text_chunks = text_splitter.split_documents(extracted_data)
    return text_chunks

# Split the extracted data into chunks
text_chunks = split_text(extracted_data)

# Initialize HuggingFace embeddings
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")  # Updated initialization

# Initialize Pinecone client
pc = Pinecone(api_key=PINECONE_API_KEY, environment=PINECONE_API_ENV)

index_name = "medical-bot"

# Load the existing index using the Pinecone vector store
docsearch = PineconeStore.from_texts(
    [t.page_content for t in text_chunks],
    embeddings,  # Correctly use the embeddings object
    index_name=index_name
)

# Create retriever from docsearch
retriever = docsearch.as_retriever(search_kwargs={'k': 2})

PROMPT = PromptTemplate(template=prompt_template, input_variables=["context", "question"])

chain_type_kwargs = {"prompt": PROMPT}

llm = CTransformers(model="model/llama-2-7b-chat.ggmlv3.q4_0.bin",
                    model_type="llama",
                    config={'max_new_tokens': 512,
                            'temperature': 0.8})

# Now use the properly instantiated retriever
qa = RetrievalQA.from_chain_type(
    llm=llm, 
    chain_type="stuff", 
    retriever=retriever,  # Use the correct retriever here
    return_source_documents=True, 
    chain_type_kwargs=chain_type_kwargs
)

@app.route("/")
def index():
    return render_template('chat.html')

# Uncomment and implement the chat route as needed
@app.route("/get", methods=["GET", "POST"])
def chat():
    msg = request.form["msg"]
    input = msg
    print(input)
    result = qa({"query": input})
    print("Response : ", result["result"])
    return str(result["result"])

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8090, debug=True)
